package com.colderonetrains.battlesskates.game.data

data class DataTrick(
    val nName       : String,
    val description : String,
    val listStep    : List<String>,
)

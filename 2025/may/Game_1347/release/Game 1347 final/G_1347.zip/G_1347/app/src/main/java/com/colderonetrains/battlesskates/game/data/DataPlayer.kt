package com.colderonetrains.battlesskates.game.data

data class DataPlayer(
    val nName       : String,
    var failedCount : Int
)

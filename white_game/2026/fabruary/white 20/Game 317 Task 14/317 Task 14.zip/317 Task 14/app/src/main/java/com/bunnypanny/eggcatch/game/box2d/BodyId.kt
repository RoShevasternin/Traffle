package com.bunnypanny.eggcatch.game.box2d

object BodyId {
    const val NONE = "none"

    object Game {
        const val AVIA  = "game.avia"
        const val COIN  = "game.coin"
        const val ENEMY = "game.enemy"
    }
}
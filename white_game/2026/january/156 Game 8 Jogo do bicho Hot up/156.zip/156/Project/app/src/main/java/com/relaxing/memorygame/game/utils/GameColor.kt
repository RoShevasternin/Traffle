package com.relaxing.memorygame.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val yellow:Color = Color.valueOf("FFE100")

}
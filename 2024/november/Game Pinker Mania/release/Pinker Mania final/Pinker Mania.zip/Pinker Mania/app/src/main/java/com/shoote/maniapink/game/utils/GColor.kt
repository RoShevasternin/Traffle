package com.shoote.maniapink.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background = Color.valueOf("000000")
    val brown_4C   = Color.valueOf("4C270E")

}
package com.roshevasternin.rozval.game.actors.checkbox

import com.shoote.maniapink.game.actors.checkbox.ACheckBox

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}
package com.shoote.maniapink.game.utils

object Global {
    var indexBackground = 0
}
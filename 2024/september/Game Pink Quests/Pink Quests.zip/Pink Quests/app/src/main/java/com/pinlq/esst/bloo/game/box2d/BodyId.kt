package com.pinlq.esst.bloo.game.box2d

object BodyId {
    const val NONE   = "none"
    const val BORDER = "border"
    const val CUBE   = "cube"

}
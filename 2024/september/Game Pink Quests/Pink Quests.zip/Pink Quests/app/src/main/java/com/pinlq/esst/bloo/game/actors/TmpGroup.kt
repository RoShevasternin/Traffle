package com.pinlq.esst.bloo.game.actors

import com.pinlq.esst.bloo.game.utils.advanced.AdvancedGroup
import com.pinlq.esst.bloo.game.utils.advanced.AdvancedScreen

class TmpGroup constructor(override val screen: AdvancedScreen): AdvancedGroup() {

    override fun addActorsOnGroup() { }

}
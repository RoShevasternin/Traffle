package com.pinlq.esst.bloo.game.utils

import com.badlogic.gdx.graphics.Color

object GColor {

    val background = Color.valueOf("000000")

    val redDark  = Color.valueOf("AA0033")
    val redLight = Color.valueOf("FF004C")

}